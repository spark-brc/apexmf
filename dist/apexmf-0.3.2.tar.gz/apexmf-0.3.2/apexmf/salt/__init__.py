"""apexmf: a set of python modules for SWAT-MODFLOW model (Bailey et al., 2021)
parameter estimation and uncertainty analysis with the open-source suite PEST (Doherty 2010a
and 2010b, and Doherty and other, 2010).
"""

# from ..utils import ObjFns